#include <iostream>
#include <algorithm>
#include <cassert>
#include <cstring>
using namespace std;

const int MAX_P = 1e5;
bool is_not_prime[MAX_P+10] = {0};

void init_prime() {
    memset(is_not_prime, false, sizeof(is_not_prime));
    is_not_prime[0] = true;
    is_not_prime[1] = true;
    for (int i = 2; i < MAX_P; i++) {
        if (!is_not_prime[i]) {
            for (int j = i+i; j < MAX_P; j += i) {
                is_not_prime[j] = true;
            }
        }
    }
}

bool is_not_prime_shift_L[int(1e6+10)] = {0};
int primes[int(1e6 + 10)];
int tot = 0;

void solve(int L, int R) {
    memset(is_not_prime_shift_L, false, sizeof(is_not_prime_shift_L));

    if (0-L >= 0) is_not_prime_shift_L[0-L] = true;
    if (1-L >= 0) is_not_prime_shift_L[1-L] = true;

    for (int i = 2; i < MAX_P; i++) {
        if (!is_not_prime[i]) {
            for (int j = L/i*i; j <= R; j += i) {
                if (j < L) continue;
                if (j == i) continue;
                is_not_prime_shift_L[j-L] = true;
            }
        }
    }

    tot = 0;
    for (int i = L; i <= R; i++) {
        if (!is_not_prime_shift_L[i-L]) {
            primes[tot++] = i;
        }
    }

    if (tot < 2) {
        cout << -1 << endl;
        return;
    }

    int min_id = 0;
    int max_id = 0;
    for (int i = 0; i < tot-1; i++) {
        if (primes[i+1] - primes[i] < primes[min_id+1] - primes[min_id]) {
            min_id = i;
        } else if (primes[i+1] - primes[i] == primes[min_id+1] - primes[min_id]) {
            if (primes[i+1] + primes[i] < primes[min_id+1] + primes[min_id]) {
                min_id = i;
            }
        }

        if (primes[i+1] - primes[i] > primes[max_id+1] - primes[max_id]) {
            max_id = i;
        } else if (primes[i+1] - primes[i] == primes[max_id+1] - primes[max_id]) {
            if (primes[i+1] + primes[i] < primes[max_id+1] + primes[max_id]) {
                max_id = i;
            }
        }
    }

    cout << primes[min_id] << " " << primes[min_id+1] << endl;
    cout << primes[max_id] << " " << primes[max_id+1] << endl;
}

int main() {
    init_prime();

    int L, R;
    cin >> L >> R;
    assert(1 <= L && L <= 1e9);
    assert(1 <= R && R <= 1e9);
    assert(L < R);
    assert(R - L <= 1e6);
    
    solve(L, R);
    return 0;
}