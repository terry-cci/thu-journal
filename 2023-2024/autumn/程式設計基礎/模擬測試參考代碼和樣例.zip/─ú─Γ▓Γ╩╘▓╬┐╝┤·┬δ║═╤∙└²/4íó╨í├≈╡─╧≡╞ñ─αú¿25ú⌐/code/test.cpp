#include <iostream>
#include <algorithm>
#include <string>
using namespace std;

typedef struct Item {
	string color;
	string shape;
} Item;
bool cmp_items(const Item & p1, const Item & p2) {
	if (p1.color == p2.color)
		return (p1.shape < p2.shape);
	return (p1.color < p2.color);
}
vector<Item> items;
int main() {
	int n = 0;
	cin >> n;
	for (int i = 0; i < n; i++) {
		string cmd;
		cin >> cmd;
		if (cmd == "CREATE") {
			Item t;
			cin >> t.color >> t.shape;
			items.push_back(t);
		} else if (cmd == "DUP") {
			Item t;
			int id = 0;
			cin >> id >> t.color;
			if (items.size() < id)
				cerr << "DUP " << id << " " << t.color << " Out of Range!" << endl;
			t.shape = items[id - 1].shape;
			items.push_back(t);
		} else if (cmd == "CRASH") {
			int id = 0;
			cin >> id;
			if (items.size() < id)
				cerr << "CRASH " << id << " Out of Range!" << endl;
			items.erase(items.begin() + (id - 1));
		} else { // ORDER
			sort(items.begin(), items.end(), cmp_items);
		}
	}
	for (int i = 0; i < items.size(); ++i)
		cout << items[i].color << " " << items[i].shape << endl;
	return 0;
}

