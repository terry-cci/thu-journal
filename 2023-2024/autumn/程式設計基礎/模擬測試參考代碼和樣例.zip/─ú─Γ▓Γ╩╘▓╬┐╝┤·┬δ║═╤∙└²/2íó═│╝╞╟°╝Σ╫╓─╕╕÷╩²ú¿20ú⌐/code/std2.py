from collections import defaultdict

def check_is_eof():
    try:
        input()
    except EOFError:
        return True
    return False

S = input()
assert(len(S) <= 1000)
for c in S:
    assert('a' <= c and c <= 'z')

Q = int(input())
assert(0 < Q and Q <= 100)

for _ in range(Q):
    l, r = [int(v) for v in input().split()]
    assert(0 <= l and l <= r and r < len(S))
    cnt = defaultdict(int)
    for i in range(l, r+1):
        cnt[S[i]] += 1
    print(" ".join([f'{c}:{cnt[c]}' for c in sorted(cnt.keys())]))

assert(check_is_eof())