#include <iostream>
#include <cstdio>
#include <cstring>
#include <cassert>
#include <cmath>
using namespace std;

char S[100000];
int Q;
int cnt[256];

void solve(int l, int r) {
    memset(cnt, 0, sizeof(cnt));
    for (int i = l; i <= r; i++) {
        assert(S[i]);
        cnt[S[i]]++;
    }
    bool is_first = true;
    for (char c = 'a'; c <= 'z'; c++) {
        if (cnt[c]) {
            if (is_first) is_first = false;
            else cout << " ";
            cout << c << ":" << cnt[c];
        }
    }
    cout << endl;
}
   
int main() {
    cin >> S;
    cin >> Q;
    assert(strlen(S) <= 1000);
    assert(0 < Q && Q <= 100);
    for (int i = 0; i < Q; i++) {
        int l, r;
        cin >> l >> r;
        assert(0 <= l && l <= r && r < strlen(S));
        solve(l, r);
    }
    return 0;
}

