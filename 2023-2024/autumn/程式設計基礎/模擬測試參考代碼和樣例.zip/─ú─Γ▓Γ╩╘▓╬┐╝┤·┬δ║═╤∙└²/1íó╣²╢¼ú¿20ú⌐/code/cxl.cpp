// CXL

#include <iostream>
#include <algorithm>
#include <cassert>
using namespace std;
int main() {
    int n;
    cin >> n;
    assert(1 <= n && n <= 1e5);
    int min_x = 2e-9;
    int min_y = 2e-9;
    int max_x = -2e-9;
    int max_y = -2e-9;

    for (int i = 0; i < n; i++) {
        int x, y;
        cin >> x >> y;
        assert(-1e9 <= x && x <= 1e9);
        assert(-1e9 <= y && y <= 1e9);
        min_x = min(min_x, x);
        max_x = max(max_x, x);
        min_y = min(min_y, y);
        max_y = max(max_y, y);
    }

    cout << max((max_y-min_y), (max_x - min_x)) << endl;

    return 0;
}
