#include <cstdio>
#include <iostream>
using namespace std;
const long long inf = 1e9 + 100; 
int main(){
	int n;
	cin >> n; 
	long long x1 = inf, x2 = -inf;
	long long y1 = inf, y2 = -inf;
	for (int i=1;i<=n;i++){
		long long x, y;
		scanf("%lld %lld", &x, &y);
		x1 = min(x1, x);
		x2 = max(x2, x);
		y1 = min(y1, y);
		y2 = max(y2, y);
	}
	long long ans = max(x2 - x1, y2 - y1);
	printf("%lld\n",ans);
	return 0;
}
