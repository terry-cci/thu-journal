#include <iostream>
#include <memory.h>
#include <algorithm>

using namespace std;

int a[1000];
int b[1000];
bool vis[10003];
int dp[10003];
int bang[10003];
int N, M;
//int search(int depth, int N, int M, int front, int sum);
int search(int len);
int main()
{
	cin >> N >> M;
	int i = N;
	while (i) {
		cin >> a[N - i + 1];
		i--;
	}
	i = N;
	while (i) {
		cin >> b[N - i + 1];
		i--;
	}
	for (int i = 1; i <= N; i++)
	{
		bang[a[i]] = max(bang[a[i]], b[i]);
	}
	int result = search(M);
	cout << result;
	return 0;
}

int search(int len)
{
	if (len < 1) return 0;
	if (vis[len]) return dp[len];
	if (bang[len] >= 0) dp[len] = bang[len];
	for (int i = 1; i < len; i++)
	{
		dp[len] = max(dp[len], search(i) + search(len - i));

	}
	if (len % 2 == 0)
		dp[len] = max(dp[len], search(len / 2) * 2 + 233);

	vis[len] = true;
	return dp[len];
}
