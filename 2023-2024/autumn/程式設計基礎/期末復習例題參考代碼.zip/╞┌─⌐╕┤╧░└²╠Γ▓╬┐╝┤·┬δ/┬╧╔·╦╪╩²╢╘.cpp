#include <iostream> 
#include <cmath>
#include <vector>
#include <string.h>
using namespace std;

vector<int> Prime(int n) 
{  
    bool* flag = new bool[n+1];   
    memset(flag, 0, (n+1)*sizeof(bool));
    vector<int> prime;
    int cnt = 0;    
    for (int i = 2; i <= n; ++i) {
        if (!flag[i]) {
            prime.push_back(i); 
            cnt++;
        }
        for (int j = 0; j < cnt; ++j) { 
            if (i * prime[j] > n)  break;
            flag[i * prime[j]] = 1;
            if (i % prime[j] == 0)  break;
        }
    }
    return prime;
}

int main()
{
	int a,b;
	cin>>a>>b;
	
	vector<int> prime = Prime(b); 
	
	int count = 0;
	for(int i=0;i<prime.size()-1;i++){
		if(prime[i]<a)continue;
		if(prime[i]+2 == prime[i+1])count++;
	}
	cout<<count<<endl;
	
	return 0;
}



