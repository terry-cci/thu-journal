﻿#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<vector>
#include<algorithm>
#include<string.h>

using namespace std;
typedef struct unit
{
	char ct[10];
	char id[15];
	int ep=-1;
	struct unit* next;
}Book;

Book* ENLIST(Book *head, char * cate, char *id, int ep);	//添加函数
Book* REMOVE(Book *head, char * id);						//删除函数
Book* REFINE(Book *head, char * cate);						//挑选函数
Book* CLEANUP(Book *head, char * cate);					//剔除函数
void Exchange(Book* node1, Book* node2);					//元素交换函数
void Print(Book* head);										//打印函数

int main()
{
	Book *head = NULL;
	int T;
	char td[20];
	cin >> T;
	for (int i = 0; i < T; i++)
	{
		cin >> td;
		if (strcmp(td, "ENLIST") == 0)		// 添加命令
		{
			char tmp_cat[10], tmp_id[15];
			int tmp_ep;
			cin >> tmp_cat >> tmp_id >> tmp_ep;
			head = ENLIST(head, tmp_cat, tmp_id, tmp_ep);
		}
		else if (strcmp(td, "REMOVE") == 0)	 //删除命令
		{
			char tmp_id[15];
			cin >> tmp_id;
			head = REMOVE(head, tmp_id);
		}
		else if (strcmp(td, "REFINE") == 0)	//挑选命令
		{
			char tmp_cat[10];
			cin >> tmp_cat;
			head = REFINE(head, tmp_cat);
		}
		else                              //剔除命令
		{
			char tmp_cat[10];
			cin >> tmp_cat;
			head = CLEANUP(head, tmp_cat);
		}
	}
	Print(head);
	return 0;
}
Book* ENLIST(Book *head, char * cate, char *id, int ep) // 添加函数
{
	Book *tmp = new Book();		//新的节点
	strcpy(tmp->ct, cate);
	strcpy(tmp->id, id);
	tmp->ep = ep;
	tmp->next = NULL;
	if(head)
	{
		tmp->next = head;	
	}
	return tmp;
}

Book* REMOVE(Book *head, char *id)	//删除函数
{
	Book * tmp = head, *tmp1=head;
	if (strcmp(head->id, id) == 0)	//判断头部节点是否为删除节点
	{
		head = head->next;
		delete tmp;
		return head;
	}
	while (tmp)
	{
		if (strcmp(tmp->id, id) == 0)	//匹配删除节点
		{
			tmp1->next = tmp->next;
			delete tmp;
			break;
		}
		tmp1 = tmp;
		tmp = tmp->next;
	}
	return head;
}
Book* REFINE(Book *head, char * cate) //挑选函数
{
	Book *tmp = head, * tmp1 = head;
	Book *ext = new Book();
	while (tmp)
	{
		if (strcmp(tmp->ct, cate) == 0)	//判断挑选对象
		{
			if (ext->ep <= tmp->ep)	//寻找期望值最大且ID最小的书
			{
				if (ext->ep == tmp->ep)
				{
					if (strcmp(ext->id, tmp->id) > 0)
					{
						strcpy(ext->ct, tmp->ct);
						strcpy(ext->id, tmp->id);
						ext->ep = tmp->ep;
					}
				}
				else
				{ 
				strcpy(ext->ct, tmp->ct);
				strcpy(ext->id, tmp->id);
				ext->ep = tmp->ep;
				}
			}
			if(head == tmp) //head节点为挑选对象
			{ 
				head = tmp->next;	
				delete tmp;
				tmp = head;
			}
			else            //其他情况
			{
				tmp1->next = tmp->next;
				delete tmp;
				tmp = tmp1;
			}
			if(tmp == NULL) 
				break;
			else 
				continue;
		}
		tmp1 = tmp;
		tmp = tmp->next;
	}
	if (ext->ep != -1)			//找到该类书籍
	{
		ext->next = head;	//放回书摞
		return ext;
	}	
	return head;
}
void Exchange(Book* node1, Book* node2) //元素交换函数
{
	char tmp_id[15], tmp_cate[10];
	int tmp_ep;

	//暂存
	strcpy(tmp_id, node2->id);
	strcpy(tmp_cate, node2->ct);
	tmp_ep = node2->ep;

	//更新node2
	strcpy(node2->id, node1->id);
	strcpy(node2->ct, node1->ct);
	node2->ep = node1->ep;

	//更新node1
	strcpy(node1->id, tmp_id);
	strcpy(node1->ct, tmp_cate);
	node1->ep = tmp_ep;
}
Book* CLEANUP(Book* head, char * cate) //剔除函数
{
	Book* tmp = head, *tmp1 = head;
	while (tmp)
	{
		if (strcmp(tmp->ct, cate) == 0) //判定应当删除元素
		{
			if (tmp == head)			//head节点处理
			{
				head = tmp->next;
				delete tmp;
				tmp = head;
				if(tmp == NULL)
					break;
				else
					continue;
			}
			else                    //其他情况
			{
				tmp1->next = tmp->next;
				delete tmp;
				tmp = tmp1->next;
				if(tmp == NULL)
					break;
				else
					continue;
			}
		}
		tmp1 = tmp;
		tmp = tmp->next;
	}
	for (tmp = head; tmp != NULL; tmp = tmp->next)	//冒泡排序
	{
		for (tmp1 = tmp->next; tmp1 != NULL; tmp1 = tmp1->next)
		{
			if (tmp->ep <= tmp1->ep)
			{
				if (tmp->ep == tmp1->ep)
				{
					if (strcmp(tmp->id, tmp1->id) > 0)
					{
						Exchange(tmp, tmp1);
					}
				}
				else
				{
					Exchange(tmp, tmp1);
				}
			}
		}
	}
	return head;
}
void Print(Book * head)	//打印函数
{
	int count = 0;
	if (head == NULL)	//书摞为空
		cout << "NULL" << endl;
	while (head)		//书摞非空
	{
		cout << head->ct << ' ' << head->id << ' ' << head->ep << endl;
		head = head->next;
		count++;
		if(count == 3)	//计数
			break;
	}
}