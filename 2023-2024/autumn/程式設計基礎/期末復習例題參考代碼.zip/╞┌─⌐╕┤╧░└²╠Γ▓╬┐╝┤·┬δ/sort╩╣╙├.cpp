﻿#include<stdio.h>
#include<algorithm>
using namespace std;

bool cmp(int x, int y) {	//定义排序规则
	return x > y;
}
int main() {
	int buf[10] = { 1,5,4,2,7,3,6 };
	sort(buf, buf + 7);			//默认从小到大排序
	for (int i = 0; i < 7; i++) {
		printf("%d ", buf[i]);
	}
	putchar('\n');

	int buf1[10] = { 1,5,4,2,7,3,6 };
	sort(buf1, buf1 + 7, cmp);	//自定义从大到小排序
	for (int i = 0; i < 7; i++) {
		printf("%d ", buf1[i]);
	}
	putchar('\n');
	return 0;
}
