/*
算法：三维dp 
定义dp[i,j,k]为前i个候选人中选择j个陪审员取得最小辩控差为k时最大的辩控和 ，我们要求的是dp[n,m,min_diff]
如何得到dp[i,j,k]呢？
考虑i-1时，为了得到i的情况：
1.如果dp[i-1][j-1][k-difference[i]]存在，而且dp[i-1][j-1][k-difference[i]]+sum[i]>dp[i,j,k]，
那么，我们选择第i个候选人，即 dp[i,j,k] = dp[i-1][j-1][k-difference[i]]+sum[i]
2.如果 dp[i-1][j-1][k-difference[i]]不存在，或者说不可达，那么我们取dp[i,j,k] = dp[i-1,j,k] 
即dp[i][j][k] = max{dp[i-1,j,k] ,  dp[i-1][j-1][k-difference[i]]+sum[i]} 
*/
 
#include <iostream>
#include <string.h>
#include <algorithm>
using namespace std;
 
const int MAX_N=201;		// 候选人最大数 
const int MAX_M=21;			// 陪审团人数最大数 
const int MAX_DIFF=801; 
 
int sum[MAX_N];				// sum[i] = d[i] + p[i]
int difference[MAX_N]; 		// difference[i] = d[i] - p[i]
int p[MAX_N];
int d[MAX_N];
int dp[MAX_N][MAX_M][MAX_DIFF];		// dp[i][j][k]=q:前i个候选人选j个陪审员最小辩控差为k时最大辩控和为q
int path[MAX_N][MAX_M][MAX_DIFF];	// path[i][j][k]=p:使dp[i][j][k]=q时选择的候选人是p 
int ans[MAX_M];						// 存放最终的结果 
 
 
int main()
{
	int n,m;
	int cases = 1;
    cin >> n >> m;
	
    memset(dp,-1,sizeof(dp));
    
    for (int i=1; i<=n; i++)
    {
        cin >> p[i] >> d[i];
        sum[i] = p[i] + d[i];
        difference[i] = p[i] - d[i];
    }
    
    // sum{sum[1..n}：最小为-400
    int max_diff = m * 20 ; 
    
    // 因辩控差的范围是[-20*m,20*m]，如果整个数组都加上20*m，其范围就变为[0,40*m]
    // 那么，原来的dp[i][0][0]，自然变成 dp[i][0][max_diff]
    for (int i=0; i<=n; i++)
    {
        dp[i][0][max_diff] = 0;
    }
    
    // dp[i,j,k]=max{dp[i-1,j,k],dp[i-1,j-1,k-difference[i]]+sum[i]}
    for (int i=1; i<=n; i++)
    {
        for (int j=1; j<=m && j<=i; j++)
        {
            for (int k=0; k<=max_diff*2; k++)
            {
                dp[i][j][k]=dp[i-1][j][k];
                path[i][j][k]=path[i-1][j][k];
                if (k>=difference[i] && k-difference[i]<=max_diff*2 && dp[i-1][j-1][k-difference[i]] >= 0 )
                {
                    if (dp[i-1][j-1][k-difference[i]]+sum[i] > dp[i][j][k])
                    {
                        dp[i][j][k] = dp[i-1][j-1][k-difference[i]]+sum[i];
                        path[i][j][k] = i;
                    }
                }
            }
        }
    }

    // 输出结果 
    int i,min_diff;
    for (i=0; i<=max_diff; i++)
    {
        if (dp[n][m][max_diff-i]>=0 || dp[n][m][max_diff+i]>=0)
        {
            break;
        }
    }
    (dp[n][m][max_diff-i] > dp[n][m][max_diff+i])? min_diff = max_diff-i : min_diff = max_diff+i;
    
    //cout<<"Jury #"<<cases++<<endl << "Best jury has value ";
    //cout<<(dp[n][m][min_diff]+min_diff-max_diff)/2<<" for prosecution and value ";
    //cout<<(dp[n][m][min_diff]-min_diff+max_diff)/2<<" for defence:"<<endl;
    cout<<(dp[n][m][min_diff]+min_diff-max_diff)/2<<" "<<(dp[n][m][min_diff]-min_diff+max_diff)/2<<endl;
    
    // dp[i][j][k] = dp[i-1][j-1][k-difference[i]]+sum[i];
    // path[i][j][k] = i;
    for (int i=n,j=m,k=min_diff; j>=1;)
    {
        int p =  path[i][j][k] ;
        ans[j] = p;
        k -= difference[p];
        j--;
        i = path[p-1][j][k];
    }
    
    for (int i=1; i<m; i++)
    {
        cout << ans[i] << " ";
    }
    cout << ans[m]<<endl; 
    //printf("\n\n");
}
