#include <iostream>

using namespace std;

bool *almost_lucky;

bool is_lucky(int n) {	//判断n是否为幸运数
	while (n) {
		if (n % 10 == 7)  return true;
		n /= 10;
	}
	return false;
}

void pre_process() {									//判断区间[0,1000005]内的近似幸运数
	for (int i = 0; i < 1000005; i++) {
		if (almost_lucky[i] == false && is_lucky(i)) {
			for (int j = 1; j * i < 1000005; j++)	//筛法：i的倍数为近似幸运数
				almost_lucky[j * i] = true;
		}
	}
}

int main() {
	almost_lucky = new bool[1000005];					//存放是否为近似幸运数
	memset(almost_lucky, false, 1000005 * sizeof(bool));	//初始化为0
	pre_process();										//预处理，判断区间[0,1000005]内的近似幸运数
	int a, b;											//区间[a,b]
	cin >> a >> b;										//输入
	int ans = 0;										//ans存放近似幸运数个数
	for (int i = a; i <= b; i++) {						//统计近似幸运数个数
		if (almost_lucky[i]) {
			ans++;
		}
	}
	cout << b - a + 1 - ans << endl;						//输出非近似幸运数个数
	return 0;
}