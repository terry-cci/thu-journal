﻿#include<vector>

using namespace std;

struct unit {	//结构体定义
	int a;
	int b;
	unit(int m, int n) :a(m), b(n) {}//构造函数，负责初始化
};

vector<int> numbers;	//定义
vector<unit> units;
int main()
{
	unit a(1, 2);
	units.push_back(a);				//在units最后添加一个元素
	units.erase(units.begin());		//删除第一个元素
	units.clear();					//清空units
	units.push_back(*(new unit(3, 4)));
	units.front();					//返回units第一个元素
	units.back();					//返回units最后一个元素
	units.insert(units.begin() + 1, *(new unit(5, 6))); //在第一个元素之后插入一个元素
	units.clear();					//清空units中的元素
	units.empty();					//判断units是否为空
	return 0;
}