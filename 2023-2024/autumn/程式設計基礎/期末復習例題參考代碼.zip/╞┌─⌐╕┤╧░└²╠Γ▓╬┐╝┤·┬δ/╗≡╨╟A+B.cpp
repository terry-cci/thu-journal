#define  _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <math.h>
#include <stdio.h>
#include <memory.h>
#include <algorithm>

using namespace std;

bool isprime(int x) {
	if (x == 0 || x == 1)
		return false;
	int i;
	for (i = 2; i <= (int)sqrt(x); i++) {
		if (x %i == 0)
			return false;
	}
	return true;
}


int main()
{
	int su[25] = { 0 };
	int a[25], b[25];
	int res[26] = { 0 };
	int a_c, b_c;
	char c;
	for (int i = 0, j = 2; i < 25; j++)
		if (isprime(j))
			su[i++] = j;
	
	memset(a, 0, sizeof(a));
	memset(b, 0, sizeof(b));
	memset(res, 0, sizeof(res));
	a_c = 0;
	b_c = 0;
	for (;;)
	{
		scanf("%d%c", &a[a_c], &c);
		if (c == ' ')
			break;
		else
			a_c++;
	}
	for (;;)
	{
		scanf("%d%c", &b[b_c], &c);
		if (c == '\n')
			break;
		else
			b_c++;
	}
	/*if (a_c == 0 && b_c == 0 && a[0] == 0 && b[0] == 0)
		break;*/
	int max_c = max(a_c, b_c);
	for (int i = max_c, j = 0; i >= 0; i--, j++)
	{
		if (i > a_c)//b��a��
		{
			if (a_c >= 0)
				res[j] = res[j] + a[a_c--] + b[i];
			else
				res[j] = res[j] + b[i];
		}
		else if (i > b_c)//a��b��
		{
			if (b_c >= 0)
				res[j] = res[j] + b[b_c--] + a[i];
			else
				res[j] = res[j] + a[i];
		}
		else//a,bһ����
			res[j] = res[j] + a[i] + b[i];
		if (res[j] >= su[j])//��λ
		{
			res[j] = res[j] - su[j];
			res[j + 1]++;
		}
	}
	if (res[max_c + 1] != 0)//�н�λ
		cout << res[max_c + 1] << ",";
	for (int i = max_c; i >= 1; i--)
		cout << res[i] << ",";
	cout << res[0] << endl;


	return 0;
}