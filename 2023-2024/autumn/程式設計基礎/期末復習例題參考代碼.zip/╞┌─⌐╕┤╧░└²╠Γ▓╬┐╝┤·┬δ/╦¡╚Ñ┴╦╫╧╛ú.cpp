#include <iostream>
using namespace std;
 
int main()
{
    char a,b,c,d;
    while(cin>>a>>b>>c>>d){
        for(char person = 'A'; person <= 'D' ; person ++)
        {
            int judge=0;
            if(person == a) judge++;
            if(person != b) judge++;
            if(person == c) judge++;
            if(person != d) judge++;
            if(judge == 2)
            {
                cout << person;
                //return 0;
            }
 
        }cout<<endl;
    }
 
}