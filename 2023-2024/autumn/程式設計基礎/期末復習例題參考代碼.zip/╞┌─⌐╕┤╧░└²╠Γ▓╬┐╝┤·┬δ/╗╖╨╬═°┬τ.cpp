﻿#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<string.h>
using namespace std;

typedef struct node {
	int delay;
	char name[7];
	struct node* next;
}Node;

Node* fun_append(Node* head, int delay, char * name);
Node* fun_sort(Node* head);
Node* fun_eliminate(Node* head, int target, int number);
Node* fun_move(Node* head, int orentation, int number);
Node* fun_delete(Node* head, char* name);
void fun_task(Node* head, char* name);
void fun_print(Node* head);

int main()
{
	Node* head = NULL;
	int num_op = 0;
	char op[20], dst_id[7], op_id[7];
	int op1, op2;
	cin >> num_op;
	while (num_op--)
	{
		cin >> op;
		if(strcmp(op, "Append") == 0)
		{
			cin >> op1 >> op_id;
			head = fun_append(head, op1, op_id);
		}
		else if(strcmp(op, "Eliminate") == 0)
		{
			cin >> op1 >> op2;
			head = fun_eliminate(head, op1, op2);
		}
		else if(strcmp(op, "Move") == 0)
		{
			cin >> op1 >> op2;
			head = fun_move(head, op1, op2);
		}
		else if(strcmp(op, "Sort") == 0)
		{
			head = fun_sort(head);
		}
		else if (strcmp(op, "Delete") == 0)
		{
			cin >> op_id;
			head = fun_delete(head, op_id);
		}
	}
	cin >> dst_id;
	fun_task(head, dst_id);
	//fun_print(head);
	return 0;

}
Node* fun_append(Node* head, int delay, char* name)
{
	Node* ptr = head;
	if (ptr == NULL)
	{
		Node* temp = new Node();
		strcpy(temp->name, name);
		temp->delay = delay;
		temp->next = temp;
		return temp;
	}
	else
	{
		while (ptr->next != head)
		{
			ptr = ptr->next;
		}
		Node* temp = new Node();
		strcpy(temp->name, name);
		temp->delay = delay;
		temp->next = head;
		ptr->next = temp;
		return head;
	}
}

Node* fun_sort(Node* head)
{
	Node* ptr = head, *ptr1 = NULL;
	char current_name[7];
	strcpy(current_name, head->name);
	while (ptr->next != head)
	{
		ptr = ptr->next;
	}
	ptr->next = NULL;
	for(ptr = head; ptr != NULL; ptr = ptr->next)
		for (ptr1 = ptr->next; ptr1 != NULL; ptr1 = ptr1->next)
		{
			if ((ptr->delay > ptr1->delay) || (ptr->delay == ptr1->delay && strcmp(ptr->name, ptr1->name) > 0))
			{
				int temp_delay;
				char temp_name[7];
				temp_delay = ptr->delay;
				strcpy(temp_name, ptr->name);
				ptr->delay = ptr1->delay;
				strcpy(ptr->name, ptr1->name);
				ptr1->delay = temp_delay;
				strcpy(ptr1->name, temp_name);
			}
		}
	ptr = head;
	while (ptr->next != NULL)
	{
		ptr = ptr->next;
	}
	ptr->next = head;
	ptr = head;
	while (true)
	{
		if (strcmp(current_name, ptr->name) == 0)
		{
			head = ptr;
			break;
		}
		ptr = ptr->next;
	}
	return head;
}

Node* fun_eliminate(Node* head, int target, int number)
{
	Node* ptr = head;
	int count = 1;
	int num = 0;
	while (num < number)
	{
		if (count % target == 0)
		{
			Node* ptr1 = ptr;
			if (ptr == head)
			{
				head = ptr->next;
			}
			while (ptr1->next != ptr)
			{
				ptr1 = ptr1->next;
			}
			ptr1->next = ptr->next;
			delete ptr;
			ptr = ptr1->next;
			num++;
			count = 1;
		 }
		else
		{
			count++;
			ptr = ptr->next;
		}
		
	}
	return head;
}

Node* fun_move(Node* head, int orentation, int number)
{
	Node* ptr = head;
	int num = 0;
	int length = 0;
	while (ptr->next != head)
	{
		ptr = ptr->next;
		length++;
	}
	length++;
	number = number % length;
	if (orentation == 1) { number = length - number; }
	while (num < number)
	{
		head = head->next;
		num++;
	}
	return head;
}

Node* fun_delete(Node* head, char* name)
{
	Node* ptr = head;
	if (ptr == NULL) return head;
	while (true)
	{
		if (strcmp((ptr->next)->name, name) == 0)
		{
			Node* temp = ptr->next;
			if (temp == head)
			{
				if (temp->next == head)
				{
					head = NULL;
				}
				else
				{
					head = head->next;
				}
			}
			ptr->next = ptr->next->next;
			delete temp;
			break;
		}
		ptr = ptr->next;
		if (ptr == head) break;
	}
	return head;
}

void fun_task(Node* head, char* name)
{
	Node* ptr = head, *dst = NULL;
	bool flag = false;
	int sum_delay = 0;
	if (head == NULL)
	{
		cout << -1 << endl;
		return;
	}
	while (ptr->next != head)
	{
		if (strcmp(ptr->name, name) == 0)
		{
			flag = true;
			dst = ptr;
			break;
		}
		ptr = ptr->next;
	}
	if (strcmp(ptr->name, name) == 0)
	{
		flag = true;
		dst = ptr;
	}
	ptr = head;
	if (flag == true)
	{
		while (ptr != dst)
		{
			cout << ptr->name << endl;
			sum_delay += ptr->delay;
			ptr = ptr->next;
		}
		cout << sum_delay << endl;
	}
	else
	{
		cout << -1 << endl;
	}
}

void fun_print(Node* head)
{
	Node* ptr = head;
	if (ptr == NULL) return;
	while (ptr->next != head)
	{
		cout << "name:" << ptr->name << '\t' << "delay:" << ptr->delay << endl;
		ptr = ptr->next;
	}
	cout << "name:" << ptr->name <<'\t'<< "delay:" << ptr->delay << endl;
}
