﻿#include<iostream>
#include<string>

using namespace std;

int main() {
	string s;	//定义string对象s
	cin >> s;	//cin输入

	char str[] = "test";
	s = str;	//字符数组对其赋值
	s += 'c';	//末尾添加一个字符
	s += "string";//末尾添加一个字符串
	string b = "class";
	s += b;		//末尾添加一个string对象

	string a = "Two";
	if (a == b)	//判断字符串是否相同
		cout << a;
	if (a <= b)	//判断字符串大小关系
		cout << a;
	string c = "cout";
	cout << c << endl;	//cout输出
	printf("%s\n", c.c_str());	//printf输出

	c.erase(1, 3);				//删除从c[1]到c[3]的字符
	for (int i = 0; i < c.size(); i++)//遍历字符串
	{
		char s = c[i];
	}

	//在string中查找b字符串
	string d = "abcdef";
	string e = "cde";
	int startPos = 0;
	int pos = d.find(e, startPos);

	//在f字符串中下标为2的位置开始插入g字符串
	string f = "AAAA";
	string g = "BBB";
	f.insert(2, g);
	cout << f << endl;
	return 0;
}