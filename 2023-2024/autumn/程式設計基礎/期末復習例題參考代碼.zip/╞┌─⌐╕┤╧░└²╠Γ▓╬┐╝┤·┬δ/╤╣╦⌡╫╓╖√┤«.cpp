#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>
#define INF 0x3f3f3f3f
using namespace std;

int best[100][100];

int calbest(string s)
{
    int n = s.size();
    for (int i = 0; i < n; i++)
    {
        best[i][i] = 1;
    }
    for (int j = 0; j < n; j++)
    {
        for (int i = j - 1; i >= 0; i--)
        {
            int nowbest = j - i + 1; //��ʼԭ�������һ
            int nowlen = j - i + 1;

            //�����
            for (int k = i; k < j; k++)
                nowbest = min(nowbest, best[i][k] + best[k + 1][j]);

            //�����
            for (int k = i; k < j; k++)
            {
                if (s[k] == s[j])
                {
                    int onelen = k - i + 1;
                    if (nowlen % onelen == 0)
                    {
                        string onestr = s.substr(i, onelen);
                        int p = k;
                        while (p < j && s[p + 1] == onestr[(p - i + 1) % onelen]) p++;
                        if (p == j)
                            nowbest = min(nowbest, int(ceil(log10(nowlen / onelen + 1))) + 2 + best[i][k]);
                    }
                }
            }
            best[i][j] = nowbest;
        }
    }
    return best[0][n - 1];
}

int main()
{
    int n;
    cin >> n;
    while (n--)
    {
        string s;
        cin >> s;
        cout << calbest(s) << endl;
    }
    return 0;
}

