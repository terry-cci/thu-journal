#include <cstdio>
#include <cassert>
int main()
{
    int n;
    scanf("%d", &n);
    assert(2 <= n && n <= 1000);
    int ans = n-1;
    for (int i = 0; i < n-2; i++) {
        int a;
        scanf("%d", &a);
        ans += a*2;
    }
    printf("%d\n", ans);
    return 0;
}