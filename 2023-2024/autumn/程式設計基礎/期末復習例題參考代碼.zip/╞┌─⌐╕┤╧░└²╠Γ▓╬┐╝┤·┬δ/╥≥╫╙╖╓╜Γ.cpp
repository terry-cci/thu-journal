#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <memory.h>

using namespace std;

//ŷ��ɸ��
void euler_sieve(int n, int* primes, int* totPrimes)
{
	bool* flag = new bool[n + 1];
	memset(flag, false, n + 1);
	for (int i = 2; i <= n; i++) 
	{
		if (!flag[i])
		{
			primes[*totPrimes] = i;
			(*totPrimes)++;
		}
		for (int j = 0; i * primes[j] <= n; j++) 
		{
			flag[i*primes[j]] = true;
			if (i % primes[j] == 0)
				break;
		}
	}
	delete[] flag;
}


int main()
{
	int n;
	cin >> n;

	int* primes = new int[n + 1];
	int totPrimes = 0;

	euler_sieve(n, primes, &totPrimes);

	bool first = true;
	for (int i = 0; i < totPrimes; i++)
	{
		while (n % primes[i] == 0) 
		{
			if (first) {
				cout << primes[i];
				first = false;
			}
			else 
				cout << "*" << primes[i];

			n = n / primes[i];
			if (n == 1) break;
		}
		if (n == 1) break;
	}
	cout << endl;
	return 0;
}