#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int month[13] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };
struct Date
{
	int y, m, d;

}now;

int is_leap(int year)
{
	if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
		return 1;
	return 0;
}

int main()
{
	int N;
	now.y = 1777, now.m = 4, now.d = 30;
	scanf("%d", &N);
	while (--N)
	{
		now.d++;
		if (now.d > month[now.m])
		{
			now.m++;
			if (now.m > 12)
			{
				now.m = 1;
				now.y++;
				if (is_leap(now.y))
					month[2] = 29;
				else
					month[2] = 28;
			}
			now.d = 1;
		}
	}
	printf("%04d-%02d-%02d\n", now.y, now.m, now.d);
	return 0;
}