#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <memory.h>

int main()
{
	int N, temp, i, j;
	int counts[11];

	memset(counts, 0, 11 * sizeof(int));

	scanf("%d", &N);
	while (N)
	{
		scanf("%d", &temp);
		counts[temp / 10]++;
		N--;
	}

	counts[9] += counts[10];
	for (i = 0; i < 10; i++)
	{
		for (j = 0; j < 10; j++)
		{
			if (counts[i] > 0)
			{
				putchar('@');
				counts[i]--;
			}
			else
			{
				putchar('.');
			}
		}
		putchar('\n');
	}
	return 0;
}