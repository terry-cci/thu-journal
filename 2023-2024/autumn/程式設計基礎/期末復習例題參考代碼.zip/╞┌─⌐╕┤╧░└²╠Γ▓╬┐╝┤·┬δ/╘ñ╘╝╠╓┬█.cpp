#include <stdio.h>
#include <time.h>
#include <cstdlib>
#include <memory>
#include <string>
#include <algorithm>
#include <cassert>
using namespace std;

long to_timestamp(int year, int month, int day, int hour, int minute, int second) {
    char time_str[128];
    sprintf(time_str, "%d-%d-%d %d:%d:%d", year, month, day, hour, minute, second);

    struct tm the_time;
    strptime(time_str,"%Y-%m-%d %H:%M:%S",&the_time);
    time_t t = mktime(&the_time);
    return t;
}

struct TaskTime {
    time_t t;
    int task_num_delta;
}task_times[100000];
int task_n = 0;

bool cmp(TaskTime a, TaskTime b) {
    return a.t < b.t;
}

void read_time(int delta) {
    int Y, M, D, H, m;
    scanf("%d%d%d%d%d", &Y, &M, &D, &H, &m);
    task_times[task_n].t = to_timestamp(Y, M, D, H, m, 0);
    task_times[task_n].task_num_delta = delta;
    task_n++;
}

int main(int argc, const char * argv[])
{
    // freopen("2.in", "r", stdin);
    int n;
    scanf("%d", &n);
    task_n = 0;
    
    task_times[task_n].t = to_timestamp(2019, 1, 1, 0, 0, 0);
    task_times[task_n].task_num_delta = 0;
    task_n ++;
    read_time(0);
    for (int i = 0; i < n; i++) {
        read_time(1);
        read_time(-1);
    }
    sort(task_times, task_times+task_n, cmp);

    int cur_task = 0;
    int max_valid_duration = 0;
    for (int i = 0; i < task_n; i++) {
        cur_task += task_times[i].task_num_delta;
        assert(cur_task == 0 || cur_task == 1);

        if (cur_task == 0 && i+1 < task_n) {
            int now_duration = task_times[i+1].t - task_times[i].t;
            if (now_duration > max_valid_duration) {
                max_valid_duration = now_duration;
            }
        }
    }
    assert(max_valid_duration % 60 == 0);
    printf("%d\n", max_valid_duration / 60);
    return 0;
}
