#define _CRT_NONSTDC_NO_DEPRECATE
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>

using namespace std;
struct card
{
	int colorId;
	int numId;
};



int main()
{

	vector<string> colorMap;
	vector<string> numMap;

	colorMap.push_back("Spade");
	colorMap.push_back("Heart");
	colorMap.push_back("Club");
	colorMap.push_back("Diamond");

	numMap.push_back("A");
	numMap.push_back("2");
	numMap.push_back("3");
	numMap.push_back("4");
	numMap.push_back("5");
	numMap.push_back("6");
	numMap.push_back("7");
	numMap.push_back("8");
	numMap.push_back("9");
	numMap.push_back("10");
	numMap.push_back("J");
	numMap.push_back("Q");
	numMap.push_back("K");

	int n;
	cin>>n;

	vector<card> cards;

	for(int i=0;i<n;i++)
	{
		string opt;
		cin>>opt;

		if(opt.compare("Append")==0){
			string color, num;
			cin>>color>>num;

			card c;

			for(int j=0;j<colorMap.size();j++){
				if(color.compare(colorMap[j])==0){
					c.colorId=j;
					break;
				}
			}

			for(int j=0;j<numMap.size();j++){
				if(num.compare(numMap[j])==0){
					c.numId=j;
					break;
				}
			}

			cards.push_back(c);

		}else if(opt.compare("Extract")==0){
			string color;
			cin>>color;

			int colorId=-1;

			for(int j=0;j<colorMap.size();j++){
				if(color.compare(colorMap[j])==0){
					colorId=j;
					break;
				}
			}


			vector<card> extractedCards;
			for(int j = cards.size()-1;j>=0;j--){
				if(cards[j].colorId==colorId){
					bool inserted = false;
					for(int k=0;k<extractedCards.size();k++){
						if(extractedCards[k].numId>=cards[j].numId){
							extractedCards.insert(extractedCards.begin()+k, cards[j]);
							inserted = true;
							break;
						}
					}
					if(!inserted){
						extractedCards.push_back(cards[j]);
					}
					cards.erase(cards.begin()+j);
				}
			}

			for(int k=extractedCards.size()-1;k>=0;k--){
				cards.insert(cards.begin(), extractedCards[k]);
			}

			extractedCards.clear();

		}else if(opt.compare("Revert")==0){
			int size = cards.size();
			for(int j=0;j<size/2;j++){
				card temp = cards[j];
				cards[j]=cards[size-1-j];
				cards[size-1-j]=temp;
			}
		}else if(opt.compare("Pop")==0){
			if(cards.size()>0)
				cards.erase(cards.begin());
		}

	}

	if(cards.size()==0){
		cout<<"null"<<endl;
	}else{
		card topCard = cards[0];
		cout<<colorMap[topCard.colorId]<<" "<<numMap[topCard.numId];
	}

	return 0;
}
