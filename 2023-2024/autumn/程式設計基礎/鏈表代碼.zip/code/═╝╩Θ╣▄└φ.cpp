#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include "string.h"

struct Book *CreatList(int m);
void PrintList(struct Book *head);
void DestroyList(Book *head);
struct Book *Delete(struct Book *head, int index);
struct Book *Reverse(struct Book *head, int start, int end);

struct Book 
{
	int id;
	char name[100];
	int price;
	struct Book *next;
};

int main()
{
	int m, n;
	struct Book *head;
	scanf("%d", &m);
	head = CreatList(m);

	scanf("%d", &n);
	while (n > 0)
	{
		char command;
		//?������
		getchar();
		scanf("%c", &command);
		if (command == 'R')
		{
			int start, end;
			scanf("%d%d", &start, &end);
			head = Reverse(head, start, end);
		}
		else if (command == 'D')
		{
			int index;
			scanf("%d", &index);
			head = Delete(head, index);
		}
		n--;
	}
	PrintList(head);
	DestroyList(head);
	return 0;
}

struct Book *CreatList(int m)
{
	struct Book *head, *p, *q;
	head = p = q = NULL;
	while (m)
	{
		q = (struct Book*)malloc(sizeof(struct Book));
		scanf("%d%s%d", &q->id, q->name, &q->price);
		if (head == NULL)
		{
			head = q;
			p = q;
		}
		else
		{
			p->next = q;
			p = q;
		}
		m--;
	}
	q->next = NULL;
	return head;
}

void PrintList(struct Book *head)
{
	while (head != NULL)
	{
		printf("%d %s %d\n", head->id, head->name, head->price);
		head = head->next;
	}
}

void DestroyList(struct Book *head)
{
	struct Book *p, *q;
	p = head;
	while (p != NULL)
	{
		q = p;
		p = p->next;
		free(q);
	}
}

struct Book *Delete(struct Book *head, int index)
{
	struct Book *p, *q;

	p = q = head;
	if (index == 1)
	{
		head = head->next;
	}
	else
	{
		while (index - 1 > 0)
		{
			q = p;
			p = p->next;
			index--;
		}
		q->next = p->next;
	}

	free(p);
	return head;
}

struct Book *Reverse(struct Book *head, int s, int t)
{
	int si = s;
	int ti = t;
	struct Book *start, *end;
	struct Book *p, *q;
	start = end = head;
	p = q = head;
	while (si - 2 > 0)
	{
		start = start->next;
		si--;
	}
	while (ti > 0)
	{
		end = end->next;
		ti--;
	}

	if (s != 1)
	{
		p = start->next;
	}
	
	int count = t - s;
	while (count >= 0)
	{
		q = p;
		p = p->next;
		q->next = end;
		end = q;
		count--;
	}
	if (si != 1)
	{
		start->next = end;
	}
	else
	{
		head = q;
	}
	
	return head;
}
