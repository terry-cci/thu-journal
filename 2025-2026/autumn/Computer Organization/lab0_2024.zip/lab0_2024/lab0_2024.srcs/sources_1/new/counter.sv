`default_nettype none
`timescale 1ns/1ps

module counter (
    // 时钟与复位信号，每个时序模块都必须包�?
    input wire clk,
    input wire reset,

    // 计数触发信号
    input wire trigger,

    // 当前计数�?
    output wire [3:0] count
);

// Actual logic goes here ...

reg[3:0] count_reg;
assign count = count_reg;

always_ff @(posedge clk) begin
    if(reset) begin
        count_reg <= 0;
    end else begin
        if(trigger) begin
            if(count_reg != 4'd15)
                count_reg <= count_reg + 1;
        end
    end
end

endmodule