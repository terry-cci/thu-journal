`default_nettype none
`timescale 1ns/1ps

module trigger (
    input wire clk,
    input wire rst,
    input wire btn,
    output reg trigger_r
);

reg prev_btn_r;

always_ff @(posedge clk) begin
    if(rst) begin
        prev_btn_r <= 1'b0;
    end else begin
        prev_btn_r <= btn;
        if(prev_btn_r == 1'b0 && btn == 1'b1)
            trigger_r <= 1'b1;
        else
            trigger_r <= 1'b0;
    end
end

endmodule