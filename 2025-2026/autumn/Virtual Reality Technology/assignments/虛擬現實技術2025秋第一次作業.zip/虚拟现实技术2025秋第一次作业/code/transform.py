import numpy as np


def identity(N):
    """
    Parameters:
    - N (int): size of the identity matrix.
    Return:
    - np.array, identity matrix of size NxN.
    """
    return np.identity(N, dtype=np.float32)


def zeros(N):
    """
    Parameters:
    - N (int): size of the zero matrix.
    Return:
    - np.array, zero matrix of size NxN.
    """
    return np.zeros((N, N), dtype=np.float32)


def normalize(v):
    """
    Parameters:
    - v (np.array): vector to be normalized.
    Return:
    - np.array, normalized unit vector.
    """
    return v / np.linalg.norm(v)


def translate(offsets):
    """
    Compute the 4x4 translation matrix.
    Parameters:
    - offsets (list of length 3): translation offsets. offsets[0], offsets[1], offsets[2] are offset on the x, y, z axis respectively.
    Return:
    - np.array, 4x4 translation matrix.
    """
    t_mat = identity(4)
    t_mat[0:3, 3] = offsets
    return t_mat


# -------------------------------------------#
#            Begin Assignment 1              #
# -------------------------------------------#

"""
Useful NumPy operations:
- degrees to radians: np.radians(angle)
- vector dot product: a.dot(b) or np.dot(a, b)
- vector cross product: np.cross(a, b)
- matrix multiplication: np.matmul(a, b) or a @ b
"""

def rotate(angle, axis):
    """
    Compute the 4x4 rotation matrix.
    Parameters:
    - angle (float): rotation angle, in degrees.
    - axis (list of length 3): the axis to rotate about.
    Return:
    - np.array, 4x4 rotation matrix.
    """
    return identity(4)


def scale(factors):
    """
    Compute the 4x4 scaling matrix.
    Parameters:
    - factors (list of length 3): scaling factors. factors[0], factors[1], factors[2] are scaling factor for the x, y, z axis respectively.
    Return:
    - np.array, 4x4 scaling matrix.
    """
    return identity(4)


def modelTransform(offsets, angles, factors):
    """
    Compute the model transformation matrix by applying transformations in the following order:
    1. scaling
    2. rotation about x(1, 0, 0)
    3. rotation about y(0, 1, 0)
    4. rotation about z(0, 0, 1)
    5. translation
    Call translate, rotate and scale implemented above to get a final model transformation matrix.
    Parameters:
    - offsets (list of length 3): translation offsets. offsets[0], offsets[1], offsets[2] are offset on the x, y, z axis respectively.
    - angles (list of length 3): rotation angles. angles[0], angles[1], angles[2] are rotation angle around the x, y, z axis respectively.
    - factors (list of length 3): scaling factors. factors[0], factors[1], factors[2] are scaling factor for the x, y, z axis respectively.
    Return:
    - np.array, 4x4 model transformation matrix.
    """
    return identity(4)


def viewTransform(ori, center, up):
    """
    Compute the view transformation matrix given camera position, look-at point, and up vector.
    We assume the camera looks at -z and up at y in the camera coordinate.
    Parameters:
    - ori (list of length 3): camera position.
    - center (list of length 3): camera look-at point.
    - up (list of length 3): camera up direction.
    Return:
    - np.array, 4x4 view transformation matrix.
    """
    return identity(4)


def perspectiveProjection(fovy, aspect, zNear, zFar):
    """
    Compute the perspective projection transformation matrix.
    Parameters:
    - fovy (float): field of view in y direction, in degrees.
    - aspect: aspect ratio of the image (width / height).
    - zNear: z value of the near clipping plane.
    - zFar: z value of the far clipping plane.
    Return:
    - np.array, 4x4 perspective projection transformation matrix.
    """
    return identity(4)


def orthogonalProjection(left, right, bottom, top, zNear, zFar):
    """
    Compute the orthogonal projection transformation matrix.
    Parameters:
    - left: x value of the left side of the near clipping plane.
    - right: x value of the right side of the near clipping plane.
    - bottom: y value of the bottom side of the near clipping plane.
    - top: y value of the top side of the near clipping plane.
    - zNear: z value of the near clipping plane.
    - zFar: z value of the far clipping plane.
    Return:
    - np.array, 4x4 orthogonal projection transformation matrix.
    """
    return identity(4)


# -------------------------------------------#
#              End Assignment 1              #
# -------------------------------------------#
