#include <stdio.h>
#include <algorithm>
using namespace std;

int ring[3]; // 转子顺序
char ring_setting[5], initial_postion[5]; // 用户输入的Ring Setting 和 Initial Position

// TODO: 填充ring_connect，reflector，ring_carry_pos数组

int ring_connect[3][26]; // 三个转子的映射关系
int reflector[26]; // 反射器的映射关系
int ring_carry_pos[3]; // 三个转子的进位位置

int ring_connect_inv[3][26]; // 经反射器后三个转子的逆映射关系 
int ring_pos[3], ring_set[3]; // Ring Position 和 Ring Setting
int plug_num; //插线板交换对数，可以为0
int plugboard[26] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}; //插线板对应情况

int main () {
    // 输入各类参数：转子顺序, Ring Setting, Initial Position和插线板交换情况
    for (int i = 0; i < 3; i++) scanf("%d", &ring[i]);
    for (int i = 0; i < 3; i++) ring[i]--;

    scanf("%s", ring_setting);
    scanf("%s", initial_postion);
    scanf("%d", &plug_num);

    // 初始化插线板
    for (int i = 0; i < plug_num; i++) {
        char x = getchar();
        while (x < 'A' || x > 'Z') x = getchar();
        char y = getchar();
        while (y < 'A' || y > 'Z') y = getchar();
        int nx = x-'A', ny = y-'A';

    // TODO: 实现插线板的交换功能

    }

    // TODO: 计算经反射器后三个转子的映射情况，完成 ring_connect_inv 的填充
    

    // 初始化 Ring Setting 和 Initial Position
    for (int i = 0; i < 3; i++) {
        ring_pos[i] = initial_postion[i]-'A';
        ring_set[i] = ring_setting[i]-'A';
    }

    // 循环处理每个字符
    while (true) {
        char x = getchar();
        if (x == EOF) break;  // 结束条件
        while (x < 'A' || x > 'Z') x = getchar();  // 跳过非字母字符

        // TODO: 判断转子的进位情况
        
        // 电路模拟
        int nx = x - 'A';

        // TODO: 实现插线板的交换

        // 进入电路
        for (int i = 2; i >= 0; i--) {

           // TODO: 根据 Ring Setting 和 Ring Position 实现字母进入的映射
        
        }

        // TODO: 通过反射器

        // 返回电路
        for (int i = 0; i < 3; i++) {

            // TODO: 根据 Ring Setting 和 Ring Position 实现字母返回的映射
        
        }

        // TODO: 通过插线板

        printf("%c", (char)(nx + 'A'));  // 输出最终密文结果
    }

    return 0;
}