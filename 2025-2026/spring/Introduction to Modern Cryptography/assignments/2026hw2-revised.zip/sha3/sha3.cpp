#include <iostream>
using namespace std;

// 轮常数
unsigned long long RC[24] = {0x0000000000000001,
                             0x0000000000008082,
                             0x800000000000808A,
                             0x8000000080008000,
                             0x000000000000808B,
                             0x0000000080000001,
                             0x8000000080008081,
                             0x8000000000008009,
                             0x000000000000008A,
                             0x0000000000000088,
                             0x0000000080008009,
                             0x000000008000000A,
                             0x000000008000808B,
                             0x800000000000008B,
                             0x8000000000008089,
                             0x8000000000008003,
                             0x8000000000008002,
                             0x8000000000000080,
                             0x000000000000800A,
                             0x800000008000000A,
                             0x8000000080008081,
                             0x8000000000008080,
                             0x0000000080000001,
                             0x8000000080008008
                            };

// Rho变换偏移
int Rho[5][5] =
    {
        {0, 36, 3, 105, 210},
        {1, 300, 10, 45, 66},
        {190, 6, 171, 15, 253},
        {28, 55, 153, 21, 120},
        {91, 276, 231, 136, 78},
    };

// Theta 步骤
void theta()
{
    // TODO: 实现 Keccak 的 Theta 变换步骤
}

// Rho 步骤
void rho()
{
    // TODO: 实现 Keccak 的 Rho 变换步骤
}

// Pi 步骤
void pi()
{
    // TODO: 实现 Keccak 的 Pi 变换步骤
}

// Chi 步骤
void chi()
{
    // TODO: 实现 Keccak 的 Chi 变换步骤
}

// Iota 步骤
void iota(int ir)
{
    // TODO: 实现 Keccak 的 Iota 变换步骤
}

// Keccak 函数
void KECCAK_P()
{
    for (int i = 0; i < 24; i++)
    {
        theta();
        rho();
        pi();
        chi();
        iota(i);
    }
}

// SHA3-256 哈希计算函数
void sha3()
{
    // TODO: 实现 SHA3-256 哈希计算，注意Padding规则
}

int main()
{
    // 输入
    string line;
    getline(cin, line);

    // TODO: 执行sha3算法并输出结果

    return 0;
}